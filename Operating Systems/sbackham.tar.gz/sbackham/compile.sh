#!/bin/bash

gcc -o print_args_envs print_args_envs.c
gcc -o shell shell.c
